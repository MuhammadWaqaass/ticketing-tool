<?php
/**
 * index.php
 * -----------------------------------------------------------
 * Main page: new-ticket form + filterable ticket queue.
 * All data loading/saving happens via AJAX calls in
 * assets/js/app.js — this file only renders the page shell.
 * -----------------------------------------------------------
 */
declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ticketing Tool</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header">
    <div class="container">
        <h1>🎫 Ticketing Tool</h1>
        <p class="tagline">Submit, track, and resolve support tickets</p>
    </div>
</header>

<main class="container">

    <!-- ============================================= -->
    <!-- Ticket submission form                         -->
    <!-- ============================================= -->
    <section class="card" aria-labelledby="new-ticket-heading">
        <h2 id="new-ticket-heading">Submit a New Ticket</h2>

        <form id="ticket-form" novalidate>
            <div class="form-grid">

                <div class="form-field">
                    <label for="title">Title <span class="required">*</span></label>
                    <input type="text" id="title" name="title" maxlength="150" required>
                    <span class="field-error" id="error-title"></span>
                </div>

                <div class="form-field">
                    <label for="priority">Priority</label>
                    <select id="priority" name="priority">
                        <option value="Low">Low</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>

                <div class="form-field">
                    <label for="requester_name">Your Name <span class="required">*</span></label>
                    <input type="text" id="requester_name" name="requester_name" maxlength="100" required>
                    <span class="field-error" id="error-requester_name"></span>
                </div>

                <div class="form-field">
                    <label for="requester_email">Your Email <span class="required">*</span></label>
                    <input type="email" id="requester_email" name="requester_email" maxlength="150" required>
                    <span class="field-error" id="error-requester_email"></span>
                </div>

                <div class="form-field">
                    <label for="assigned_to">Assign To (optional)</label>
                    <input type="text" id="assigned_to" name="assigned_to" list="staff-list" maxlength="100" placeholder="Unassigned">
                    <datalist id="staff-list">
                        <option value="Mike Chen">
                        <option value="Priya Patel">
                        <option value="Unassigned">
                    </datalist>
                </div>

                <div class="form-field form-field-full">
                    <label for="description">Description <span class="required">*</span></label>
                    <textarea id="description" name="description" rows="4" required></textarea>
                    <span class="field-error" id="error-description"></span>
                </div>

            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Submit Ticket</button>
                <span id="form-message" class="form-message" role="status" aria-live="polite"></span>
            </div>
        </form>
    </section>

    <!-- ============================================= -->
    <!-- Filters / search                               -->
    <!-- ============================================= -->
    <section class="card" aria-labelledby="filters-heading">
        <h2 id="filters-heading">Ticket Queue</h2>

        <div class="filters-bar">
            <div class="form-field">
                <label for="filter-search">Search</label>
                <input type="search" id="filter-search" placeholder="Title, description, requester, email...">
            </div>

            <div class="form-field">
                <label for="filter-status">Status</label>
                <select id="filter-status">
                    <option value="">All Statuses</option>
                    <option value="Open">Open</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Closed">Closed</option>
                </select>
            </div>

            <div class="form-field">
                <label for="filter-priority">Priority</label>
                <select id="filter-priority">
                    <option value="">All Priorities</option>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                </select>
            </div>

            <div class="form-field">
                <label for="filter-assigned">Assignee</label>
                <select id="filter-assigned">
                    <option value="">All Assignees</option>
                    <option value="Unassigned">Unassigned</option>
                    <option value="Mike Chen">Mike Chen</option>
                    <option value="Priya Patel">Priya Patel</option>
                </select>
            </div>

            <button type="button" id="clear-filters" class="btn btn-secondary">Clear Filters</button>
        </div>

        <!-- Ticket count + loading/empty states -->
        <p id="queue-status" class="queue-status" aria-live="polite"></p>

        <!-- ============================================= -->
        <!-- Ticket table                                   -->
        <!-- ============================================= -->
        <div class="table-wrapper">
            <table class="ticket-table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Title</th>
                        <th scope="col">Requester</th>
                        <th scope="col">Assigned To</th>
                        <th scope="col">Priority</th>
                        <th scope="col">Status</th>
                        <th scope="col">Created</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody id="ticket-table-body">
                    <!-- Rows injected by app.js -->
                </tbody>
            </table>
        </div>
    </section>

</main>

<!-- ============================================= -->
<!-- View / Edit ticket modal                       -->
<!-- ============================================= -->
<div id="ticket-modal" class="modal-overlay" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <button type="button" id="modal-close" class="modal-close" aria-label="Close dialog">&times;</button>

        <h2 id="modal-title">Ticket Details</h2>

        <form id="edit-ticket-form">
            <input type="hidden" id="edit-id" name="id">

            <div class="form-grid">
                <div class="form-field form-field-full">
                    <label for="edit-title">Title <span class="required">*</span></label>
                    <input type="text" id="edit-title" name="title" maxlength="150" required>
                    <span class="field-error" id="edit-error-title"></span>
                </div>

                <div class="form-field form-field-full">
                    <label for="edit-description">Description <span class="required">*</span></label>
                    <textarea id="edit-description" name="description" rows="4" required></textarea>
                    <span class="field-error" id="edit-error-description"></span>
                </div>

                <div class="form-field">
                    <label for="edit-requester_name">Requester Name <span class="required">*</span></label>
                    <input type="text" id="edit-requester_name" name="requester_name" maxlength="100" required>
                    <span class="field-error" id="edit-error-requester_name"></span>
                </div>

                <div class="form-field">
                    <label for="edit-requester_email">Requester Email <span class="required">*</span></label>
                    <input type="email" id="edit-requester_email" name="requester_email" maxlength="150" required>
                    <span class="field-error" id="edit-error-requester_email"></span>
                </div>

                <div class="form-field">
                    <label for="edit-assigned_to">Assigned To</label>
                    <input type="text" id="edit-assigned_to" name="assigned_to" list="staff-list" maxlength="100">
                </div>

                <div class="form-field">
                    <label for="edit-priority">Priority</label>
                    <select id="edit-priority" name="priority">
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>

                <div class="form-field">
                    <label for="edit-status">Status</label>
                    <select id="edit-status" name="status">
                        <option value="Open">Open</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                        <option value="Closed">Closed</option>
                    </select>
                </div>
            </div>

            <p class="modal-meta" id="modal-meta"></p>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <button type="button" id="delete-ticket-btn" class="btn btn-danger">Delete Ticket</button>
                <span id="edit-form-message" class="form-message" role="status" aria-live="polite"></span>
            </div>
        </form>
    </div>
</div>

<!-- Simple toast notification for success / error messages -->
<div id="toast" class="toast" role="alert" aria-live="assertive" hidden></div>

<script src="assets/js/app.js"></script>
</body>
</html>
