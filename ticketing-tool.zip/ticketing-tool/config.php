<?php
/**
 * config.php
 * -----------------------------------------------------------
 * Central database connection using PDO.
 * Every API file (and index.php) includes this file to get
 * a ready-to-use $pdo connection object.
 * -----------------------------------------------------------
 */

declare(strict_types=1);

// ---- Adjust these to match your local MySQL / XAMPP setup ----
$DB_HOST = 'localhost';
$DB_NAME = 'ticketing_tool';
$DB_USER = 'root';
$DB_PASS = '';       // default XAMPP password is empty
$DB_CHARSET = 'utf8mb4';

$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // throw exceptions on error
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,          // return rows as associative arrays
    PDO::ATTR_EMULATE_PREPARES   => false,                     // use real prepared statements
];

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (PDOException $e) {
    // If the DB connection itself fails, every API endpoint needs to
    // respond with JSON (not an HTML error page), so we do that here too.
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed. Please check config.php and make sure MySQL is running.',
        'data'    => null,
    ]);
    exit;
}
