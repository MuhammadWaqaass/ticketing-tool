<?php
/**
 * api/create_ticket.php
 * -----------------------------------------------------------
 * POST endpoint - creates a new ticket.
 * Expects JSON (or form-encoded) body with:
 *   title, description, requester_name, requester_email,
 *   assigned_to (optional), priority (optional), status (optional)
 * -----------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(false, 'Only POST requests are allowed on this endpoint.', null, 405);
}

$input = get_request_body();

// ---- Server-side validation (never trust the client) ----
$errors = validate_ticket_fields($input, true);
if (!empty($errors)) {
    send_json(false, implode(' ', $errors), null, 422);
}

$title           = clean($input['title']);
$description     = clean($input['description']);
$requesterName   = clean($input['requester_name']);
$requesterEmail  = clean($input['requester_email']);
$assignedTo      = clean($input['assigned_to'] ?? '') ?: 'Unassigned';
$priority        = clean($input['priority'] ?? '') ?: 'Medium';
$status          = clean($input['status'] ?? '') ?: 'Open';

try {
    $stmt = $pdo->prepare(
        'INSERT INTO tickets
            (title, description, requester_name, requester_email, assigned_to, priority, status)
         VALUES
            (:title, :description, :requester_name, :requester_email, :assigned_to, :priority, :status)'
    );

    $stmt->execute([
        ':title'            => $title,
        ':description'      => $description,
        ':requester_name'   => $requesterName,
        ':requester_email'  => $requesterEmail,
        ':assigned_to'      => $assignedTo,
        ':priority'         => $priority,
        ':status'           => $status,
    ]);

    $newId = (int) $pdo->lastInsertId();

    // Fetch the freshly created ticket so the frontend can render it immediately.
    $fetch = $pdo->prepare('SELECT * FROM tickets WHERE id = :id');
    $fetch->execute([':id' => $newId]);
    $ticket = $fetch->fetch();

    send_json(true, 'Ticket created successfully.', $ticket, 201);
} catch (PDOException $e) {
    send_json(false, 'Failed to create ticket: ' . $e->getMessage(), null, 500);
}
