<?php
/**
 * api/get_ticket.php
 * -----------------------------------------------------------
 * GET endpoint - returns a single ticket by id.
 * Usage: get_ticket.php?id=5
 * -----------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json(false, 'Only GET requests are allowed on this endpoint.', null, 405);
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id <= 0) {
    send_json(false, 'A valid ticket id is required.', null, 422);
}

try {
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $ticket = $stmt->fetch();

    if (!$ticket) {
        send_json(false, 'Ticket not found.', null, 404);
    }

    send_json(true, 'Ticket retrieved successfully.', $ticket);
} catch (PDOException $e) {
    send_json(false, 'Failed to retrieve ticket: ' . $e->getMessage(), null, 500);
}
