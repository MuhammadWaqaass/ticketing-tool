<?php
/**
 * api/get_tickets.php
 * -----------------------------------------------------------
 * GET endpoint - returns a (optionally filtered/searched) list
 * of all tickets, newest first.
 *
 * Supported query string parameters (all optional):
 *   q            - keyword search across title, description,
 *                  requester_name, requester_email
 *   status       - exact match: Open | In Progress | Resolved | Closed
 *   priority     - exact match: Low | Medium | High
 *   assigned_to  - exact match on assignee name
 * -----------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json(false, 'Only GET requests are allowed on this endpoint.', null, 405);
}

$search     = clean($_GET['q'] ?? '');
$status     = clean($_GET['status'] ?? '');
$priority   = clean($_GET['priority'] ?? '');
$assignedTo = clean($_GET['assigned_to'] ?? '');

$where  = [];
$params = [];

if ($search !== '') {
    $where[] = '(title LIKE :search
                 OR description LIKE :search
                 OR requester_name LIKE :search
                 OR requester_email LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}

$validStatuses   = ['Open', 'In Progress', 'Resolved', 'Closed'];
$validPriorities = ['Low', 'Medium', 'High'];

if ($status !== '' && in_array($status, $validStatuses, true)) {
    $where[] = 'status = :status';
    $params[':status'] = $status;
}

if ($priority !== '' && in_array($priority, $validPriorities, true)) {
    $where[] = 'priority = :priority';
    $params[':priority'] = $priority;
}

if ($assignedTo !== '') {
    $where[] = 'assigned_to = :assigned_to';
    $params[':assigned_to'] = $assignedTo;
}

$sql = 'SELECT * FROM tickets';
if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY created_at DESC';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $tickets = $stmt->fetchAll();

    send_json(true, 'Tickets retrieved successfully.', $tickets);
} catch (PDOException $e) {
    send_json(false, 'Failed to retrieve tickets: ' . $e->getMessage(), null, 500);
}
