<?php
/**
 * api/update_ticket.php
 * -----------------------------------------------------------
 * POST endpoint - updates an existing ticket.
 * Accepts a partial update: only the fields present in the
 * request body are changed (useful for quick inline status /
 * assignee changes as well as the full edit form).
 *
 * Expects JSON body with at least:
 *   id
 * and any of:
 *   title, description, requester_name, requester_email,
 *   assigned_to, priority, status
 * -----------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(false, 'Only POST requests are allowed on this endpoint.', null, 405);
}

$input = get_request_body();

$id = isset($input['id']) ? (int) $input['id'] : 0;
if ($id <= 0) {
    send_json(false, 'A valid ticket id is required.', null, 422);
}

// Make sure the ticket actually exists first.
$check = $pdo->prepare('SELECT id FROM tickets WHERE id = :id');
$check->execute([':id' => $id]);
if (!$check->fetch()) {
    send_json(false, 'Ticket not found.', null, 404);
}

// Only validate the fields that were actually submitted.
$errors = validate_ticket_fields($input, false);
if (!empty($errors)) {
    send_json(false, implode(' ', $errors), null, 422);
}

// Build the SET clause dynamically from whichever editable fields were sent.
$editableFields = [
    'title', 'description', 'requester_name', 'requester_email',
    'assigned_to', 'priority', 'status',
];

$setParts = [];
$params   = [':id' => $id];

foreach ($editableFields as $field) {
    if (array_key_exists($field, $input)) {
        $setParts[]        = "{$field} = :{$field}";
        $params[":{$field}"] = clean((string) $input[$field]);
    }
}

if (empty($setParts)) {
    send_json(false, 'No valid fields were provided to update.', null, 422);
}

$sql = 'UPDATE tickets SET ' . implode(', ', $setParts) . ' WHERE id = :id';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $fetch = $pdo->prepare('SELECT * FROM tickets WHERE id = :id');
    $fetch->execute([':id' => $id]);
    $ticket = $fetch->fetch();

    send_json(true, 'Ticket updated successfully.', $ticket);
} catch (PDOException $e) {
    send_json(false, 'Failed to update ticket: ' . $e->getMessage(), null, 500);
}
