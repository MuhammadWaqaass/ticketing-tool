<?php
/**
 * api/delete_ticket.php
 * -----------------------------------------------------------
 * POST endpoint - deletes a ticket by id.
 * Expects JSON body: { "id": 5 }
 * (POST is used instead of DELETE for maximum compatibility
 * with simple hosting setups / form submissions.)
 * -----------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(false, 'Only POST requests are allowed on this endpoint.', null, 405);
}

$input = get_request_body();
$id = isset($input['id']) ? (int) $input['id'] : 0;

if ($id <= 0) {
    send_json(false, 'A valid ticket id is required.', null, 422);
}

try {
    $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->execute([':id' => $id]);

    if ($stmt->rowCount() === 0) {
        send_json(false, 'Ticket not found (it may already have been deleted).', null, 404);
    }

    send_json(true, 'Ticket deleted successfully.', ['id' => $id]);
} catch (PDOException $e) {
    send_json(false, 'Failed to delete ticket: ' . $e->getMessage(), null, 500);
}
