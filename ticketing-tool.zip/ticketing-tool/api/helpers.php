<?php
/**
 * api/helpers.php
 * -----------------------------------------------------------
 * Small shared helpers used by every endpoint in api/.
 * Keeping this in one place keeps the JSON response shape
 * ({success, message, data}) consistent across all endpoints.
 * -----------------------------------------------------------
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

/**
 * Send a JSON response and stop execution.
 */
function send_json(bool $success, string $message, $data = null, int $httpCode = 200): void
{
    http_response_code($httpCode);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data'    => $data,
    ]);
    exit;
}

/**
 * Read and decode a JSON request body into an associative array.
 * Falls back to $_POST so plain form submissions still work.
 */
function get_request_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && $raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return $_POST;
}

/**
 * Trim a value if it's a string, otherwise return it unchanged.
 */
function clean(?string $value): string
{
    return trim((string) $value);
}

/**
 * Validate the incoming ticket fields.
 * $requireAll = true for ticket creation (all core fields mandatory).
 * $requireAll = false for updates (only validate fields that were sent).
 *
 * Returns an array of human-readable error strings (empty = valid).
 */
function validate_ticket_fields(array $input, bool $requireAll = true): array
{
    $errors = [];

    $validPriorities = ['Low', 'Medium', 'High'];
    $validStatuses   = ['Open', 'In Progress', 'Resolved', 'Closed'];

    // Title
    if ($requireAll || array_key_exists('title', $input)) {
        $title = clean($input['title'] ?? '');
        if ($title === '') {
            $errors[] = 'Title is required.';
        } elseif (mb_strlen($title) > 150) {
            $errors[] = 'Title must be 150 characters or fewer.';
        }
    }

    // Description
    if ($requireAll || array_key_exists('description', $input)) {
        $description = clean($input['description'] ?? '');
        if ($description === '') {
            $errors[] = 'Description is required.';
        }
    }

    // Requester name
    if ($requireAll || array_key_exists('requester_name', $input)) {
        $name = clean($input['requester_name'] ?? '');
        if ($name === '') {
            $errors[] = 'Requester name is required.';
        } elseif (mb_strlen($name) > 100) {
            $errors[] = 'Requester name must be 100 characters or fewer.';
        }
    }

    // Requester email
    if ($requireAll || array_key_exists('requester_email', $input)) {
        $email = clean($input['requester_email'] ?? '');
        if ($email === '') {
            $errors[] = 'Requester email is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Requester email must be a valid email address.';
        }
    }

    // Priority
    if (array_key_exists('priority', $input)) {
        $priority = clean($input['priority'] ?? '');
        if ($priority !== '' && !in_array($priority, $validPriorities, true)) {
            $errors[] = 'Priority must be one of: Low, Medium, High.';
        }
    } elseif ($requireAll) {
        // Priority has a DB default, so it's optional even when creating.
    }

    // Status
    if (array_key_exists('status', $input)) {
        $status = clean($input['status'] ?? '');
        if ($status !== '' && !in_array($status, $validStatuses, true)) {
            $errors[] = 'Status must be one of: Open, In Progress, Resolved, Closed.';
        }
    }

    // Assigned to (optional free-text field, just cap the length)
    if (array_key_exists('assigned_to', $input)) {
        $assignedTo = clean($input['assigned_to'] ?? '');
        if (mb_strlen($assignedTo) > 100) {
            $errors[] = 'Assigned To must be 100 characters or fewer.';
        }
    }

    return $errors;
}
