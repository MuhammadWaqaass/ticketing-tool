/**
 * assets/js/app.js
 * -----------------------------------------------------------
 * Vanilla JS + Fetch API driving the whole Ticketing Tool UI:
 *   - loading & rendering the ticket queue
 *   - client-side validation + AJAX create
 *   - search / filter (debounced)
 *   - view/edit modal + AJAX update
 *   - AJAX delete with confirmation
 * No frameworks, no libraries.
 * -----------------------------------------------------------
 */

(function () {
    'use strict';

    // ---------------------------------------------------------
    // Config / element references
    // ---------------------------------------------------------
    const API = {
        list:   'api/get_tickets.php',
        single: 'api/get_ticket.php',
        create: 'api/create_ticket.php',
        update: 'api/update_ticket.php',
        remove: 'api/delete_ticket.php',
    };

    const ticketForm      = document.getElementById('ticket-form');
    const formMessage     = document.getElementById('form-message');

    const tableBody       = document.getElementById('ticket-table-body');
    const queueStatus     = document.getElementById('queue-status');

    const filterSearch    = document.getElementById('filter-search');
    const filterStatus    = document.getElementById('filter-status');
    const filterPriority  = document.getElementById('filter-priority');
    const filterAssigned  = document.getElementById('filter-assigned');
    const clearFiltersBtn = document.getElementById('clear-filters');

    const modal            = document.getElementById('ticket-modal');
    const modalCloseBtn    = document.getElementById('modal-close');
    const editForm         = document.getElementById('edit-ticket-form');
    const editFormMessage  = document.getElementById('edit-form-message');
    const modalMeta        = document.getElementById('modal-meta');
    const deleteBtn         = document.getElementById('delete-ticket-btn');

    const toast = document.getElementById('toast');

    let currentEditId = null;
    let searchDebounceTimer = null;

    // ---------------------------------------------------------
    // Small utilities
    // ---------------------------------------------------------

    /** Escape text before inserting into innerHTML, to prevent XSS. */
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str === null || str === undefined ? '' : String(str);
        return div.innerHTML;
    }

    function showToast(message, isError) {
        toast.textContent = message;
        toast.classList.toggle('error', !!isError);
        toast.hidden = false;
        clearTimeout(showToast._timer);
        showToast._timer = setTimeout(() => { toast.hidden = true; }, 3500);
    }

    function formatDate(isoLike) {
        if (!isoLike) return '';
        // MySQL returns "YYYY-MM-DD HH:MM:SS"; make it Safari/JS friendly.
        const safe = isoLike.replace(' ', 'T');
        const d = new Date(safe);
        if (isNaN(d.getTime())) return isoLike;
        return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) +
               ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    }

    function slugify(text) {
        return String(text).toLowerCase().replace(/\s+/g, '-');
    }

    async function callApi(url, options) {
        const response = await fetch(url, options);
        let json;
        try {
            json = await response.json();
        } catch (e) {
            throw new Error('Server returned an unexpected response.');
        }
        return json; // { success, message, data }
    }

    // ---------------------------------------------------------
    // Client-side validation (mirrors server-side rules)
    // ---------------------------------------------------------
    function validateFields(values, prefix) {
        const errors = {};

        if (!values.title || !values.title.trim()) {
            errors.title = 'Title is required.';
        } else if (values.title.length > 150) {
            errors.title = 'Title must be 150 characters or fewer.';
        }

        if (!values.description || !values.description.trim()) {
            errors.description = 'Description is required.';
        }

        if (!values.requester_name || !values.requester_name.trim()) {
            errors.requester_name = 'Requester name is required.';
        }

        if (!values.requester_email || !values.requester_email.trim()) {
            errors.requester_email = 'Requester email is required.';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.requester_email)) {
            errors.requester_email = 'Enter a valid email address.';
        }

        // Apply to the DOM
        Object.keys(errors).forEach((field) => {
            const el = document.getElementById(`${prefix}error-${field}`);
            if (el) el.textContent = errors[field];
        });
        // Clear any previous errors for fields that are now valid
        ['title', 'description', 'requester_name', 'requester_email'].forEach((field) => {
            if (!errors[field]) {
                const el = document.getElementById(`${prefix}error-${field}`);
                if (el) el.textContent = '';
            }
        });

        return Object.keys(errors).length === 0;
    }

    function clearFieldErrors(prefix) {
        ['title', 'description', 'requester_name', 'requester_email'].forEach((field) => {
            const el = document.getElementById(`${prefix}error-${field}`);
            if (el) el.textContent = '';
        });
    }

    // ---------------------------------------------------------
    // Rendering the ticket queue
    // ---------------------------------------------------------
    function priorityBadge(priority) {
        return `<span class="badge badge-priority-${slugify(priority)}">${escapeHtml(priority)}</span>`;
    }

    function statusBadge(status) {
        return `<span class="badge badge-status-${slugify(status)}">${escapeHtml(status)}</span>`;
    }

    function renderTickets(tickets) {
        if (!tickets || tickets.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">No tickets match your current filters.</td>
                </tr>`;
            return;
        }

        tableBody.innerHTML = tickets.map((t) => `
            <tr data-id="${t.id}">
                <td>#${t.id}</td>
                <td class="title-cell">${escapeHtml(t.title)}</td>
                <td>${escapeHtml(t.requester_name)}</td>
                <td>${escapeHtml(t.assigned_to)}</td>
                <td>${priorityBadge(t.priority)}</td>
                <td>${statusBadge(t.status)}</td>
                <td>${formatDate(t.created_at)}</td>
                <td class="row-actions">
                    <button type="button" class="btn btn-secondary btn-small" data-action="view" data-id="${t.id}">View</button>
                    <button type="button" class="btn btn-secondary btn-small" data-action="edit" data-id="${t.id}">Edit</button>
                    <button type="button" class="btn btn-danger btn-small" data-action="delete" data-id="${t.id}">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    function buildQueryString() {
        const params = new URLSearchParams();
        if (filterSearch.value.trim()) params.set('q', filterSearch.value.trim());
        if (filterStatus.value) params.set('status', filterStatus.value);
        if (filterPriority.value) params.set('priority', filterPriority.value);
        if (filterAssigned.value) params.set('assigned_to', filterAssigned.value);
        return params.toString();
    }

    async function loadTickets() {
        queueStatus.textContent = 'Loading tickets...';
        try {
            const qs = buildQueryString();
            const result = await callApi(`${API.list}${qs ? '?' + qs : ''}`);

            if (!result.success) {
                queueStatus.textContent = result.message || 'Failed to load tickets.';
                renderTickets([]);
                return;
            }

            renderTickets(result.data);
            const count = result.data.length;
            queueStatus.textContent = `${count} ticket${count === 1 ? '' : 's'} found.`;
        } catch (err) {
            queueStatus.textContent = 'Could not reach the server. Please try again.';
            renderTickets([]);
        }
    }

    // ---------------------------------------------------------
    // Create ticket
    // ---------------------------------------------------------
    ticketForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const values = {
            title: document.getElementById('title').value.trim(),
            description: document.getElementById('description').value.trim(),
            requester_name: document.getElementById('requester_name').value.trim(),
            requester_email: document.getElementById('requester_email').value.trim(),
            assigned_to: document.getElementById('assigned_to').value.trim(),
            priority: document.getElementById('priority').value,
        };

        clearFieldErrors('error-');
        formMessage.textContent = '';
        formMessage.className = 'form-message';

        if (!validateFields(values, 'error-')) {
            formMessage.textContent = 'Please fix the highlighted fields.';
            formMessage.classList.add('error');
            return;
        }

        const submitBtn = ticketForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;

        try {
            const result = await callApi(API.create, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values),
            });

            if (result.success) {
                formMessage.textContent = result.message || 'Ticket created!';
                formMessage.classList.add('success');
                ticketForm.reset();
                document.getElementById('priority').value = 'Medium';
                showToast('Ticket created successfully.', false);
                loadTickets();
            } else {
                formMessage.textContent = result.message || 'Failed to create ticket.';
                formMessage.classList.add('error');
            }
        } catch (err) {
            formMessage.textContent = 'Could not reach the server. Please try again.';
            formMessage.classList.add('error');
        } finally {
            submitBtn.disabled = false;
        }
    });

    // ---------------------------------------------------------
    // Filters (search is debounced; dropdowns apply immediately)
    // ---------------------------------------------------------
    filterSearch.addEventListener('input', () => {
        clearTimeout(searchDebounceTimer);
        searchDebounceTimer = setTimeout(loadTickets, 350);
    });

    [filterStatus, filterPriority, filterAssigned].forEach((el) => {
        el.addEventListener('change', loadTickets);
    });

    clearFiltersBtn.addEventListener('click', () => {
        filterSearch.value = '';
        filterStatus.value = '';
        filterPriority.value = '';
        filterAssigned.value = '';
        loadTickets();
    });

    // ---------------------------------------------------------
    // Table action buttons (event delegation)
    // ---------------------------------------------------------
    tableBody.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-action]');
        if (!btn) return;

        const id = btn.getAttribute('data-id');
        const action = btn.getAttribute('data-action');

        if (action === 'view' || action === 'edit') {
            openTicketModal(id);
        } else if (action === 'delete') {
            deleteTicket(id);
        }
    });

    // ---------------------------------------------------------
    // View / Edit modal
    // ---------------------------------------------------------
    async function openTicketModal(id) {
        editFormMessage.textContent = '';
        editFormMessage.className = 'form-message';
        clearFieldErrors('edit-error-');

        try {
            const result = await callApi(`${API.single}?id=${encodeURIComponent(id)}`);
            if (!result.success) {
                showToast(result.message || 'Could not load ticket.', true);
                return;
            }

            const t = result.data;
            currentEditId = t.id;

            document.getElementById('edit-id').value = t.id;
            document.getElementById('edit-title').value = t.title;
            document.getElementById('edit-description').value = t.description;
            document.getElementById('edit-requester_name').value = t.requester_name;
            document.getElementById('edit-requester_email').value = t.requester_email;
            document.getElementById('edit-assigned_to').value = t.assigned_to;
            document.getElementById('edit-priority').value = t.priority;
            document.getElementById('edit-status').value = t.status;

            modalMeta.textContent =
                `Ticket #${t.id} · Created ${formatDate(t.created_at)} · Last updated ${formatDate(t.updated_at)}`;

            modal.hidden = false;
            document.getElementById('edit-title').focus();
        } catch (err) {
            showToast('Could not reach the server. Please try again.', true);
        }
    }

    function closeModal() {
        modal.hidden = true;
        currentEditId = null;
    }

    modalCloseBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal(); // click outside the dialog
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !modal.hidden) closeModal();
    });

    // ---- Save changes (update) ----
    editForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!currentEditId) return;

        const values = {
            id: currentEditId,
            title: document.getElementById('edit-title').value.trim(),
            description: document.getElementById('edit-description').value.trim(),
            requester_name: document.getElementById('edit-requester_name').value.trim(),
            requester_email: document.getElementById('edit-requester_email').value.trim(),
            assigned_to: document.getElementById('edit-assigned_to').value.trim(),
            priority: document.getElementById('edit-priority').value,
            status: document.getElementById('edit-status').value,
        };

        clearFieldErrors('edit-error-');
        editFormMessage.textContent = '';
        editFormMessage.className = 'form-message';

        if (!validateFields(values, 'edit-error-')) {
            editFormMessage.textContent = 'Please fix the highlighted fields.';
            editFormMessage.classList.add('error');
            return;
        }

        const saveBtn = editForm.querySelector('button[type="submit"]');
        saveBtn.disabled = true;

        try {
            const result = await callApi(API.update, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values),
            });

            if (result.success) {
                editFormMessage.textContent = result.message || 'Ticket updated.';
                editFormMessage.classList.add('success');
                showToast('Ticket updated successfully.', false);
                loadTickets();
                setTimeout(closeModal, 500);
            } else {
                editFormMessage.textContent = result.message || 'Failed to update ticket.';
                editFormMessage.classList.add('error');
            }
        } catch (err) {
            editFormMessage.textContent = 'Could not reach the server. Please try again.';
            editFormMessage.classList.add('error');
        } finally {
            saveBtn.disabled = false;
        }
    });

    // ---- Delete from within the modal ----
    deleteBtn.addEventListener('click', () => {
        if (!currentEditId) return;
        deleteTicket(currentEditId, closeModal);
    });

    // ---------------------------------------------------------
    // Delete ticket (used by both table row buttons and modal)
    // ---------------------------------------------------------
    async function deleteTicket(id, onSuccess) {
        const confirmed = window.confirm(`Delete ticket #${id}? This cannot be undone.`);
        if (!confirmed) return;

        try {
            const result = await callApi(API.remove, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id }),
            });

            if (result.success) {
                showToast('Ticket deleted.', false);
                loadTickets();
                if (typeof onSuccess === 'function') onSuccess();
            } else {
                showToast(result.message || 'Failed to delete ticket.', true);
            }
        } catch (err) {
            showToast('Could not reach the server. Please try again.', true);
        }
    }

    // ---------------------------------------------------------
    // Initial load
    // ---------------------------------------------------------
    document.addEventListener('DOMContentLoaded', loadTickets);
    // In case this script is loaded after DOMContentLoaded already fired:
    if (document.readyState !== 'loading') {
        loadTickets();
    }
})();
