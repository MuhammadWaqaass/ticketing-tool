-- =========================================================
-- Ticketing Tool - Database Schema
-- =========================================================
-- Run this file in phpMyAdmin, or via:
--   mysql -u root -p < database.sql
-- =========================================================

CREATE DATABASE IF NOT EXISTS ticketing_tool
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ticketing_tool;

DROP TABLE IF EXISTS tickets;

CREATE TABLE tickets (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title             VARCHAR(150)    NOT NULL,
    description       TEXT            NOT NULL,
    requester_name    VARCHAR(100)    NOT NULL,
    requester_email   VARCHAR(150)    NOT NULL,
    assigned_to       VARCHAR(100)    NOT NULL DEFAULT 'Unassigned',
    priority          ENUM('Low', 'Medium', 'High') NOT NULL DEFAULT 'Medium',
    status            ENUM('Open', 'In Progress', 'Resolved', 'Closed') NOT NULL DEFAULT 'Open',
    created_at        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Indexes to speed up filtering/searching on the dashboard
    INDEX idx_status      (status),
    INDEX idx_priority     (priority),
    INDEX idx_assigned_to  (assigned_to),
    INDEX idx_created_at   (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Sample data
-- =========================================================
INSERT INTO tickets
    (title, description, requester_name, requester_email, assigned_to, priority, status, created_at, updated_at)
VALUES
('Cannot log into account',
 'I keep getting an "invalid credentials" error even though I am sure my password is correct. I already tried resetting it twice.',
 'Sarah Johnson', 'sarah.johnson@example.com', 'Mike Chen', 'High', 'In Progress',
 DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY)),

('Invoice PDF not downloading',
 'When I click "Download Invoice" on the billing page, the button spins forever and nothing happens.',
 'David Park', 'david.park@example.com', 'Unassigned', 'Medium', 'Open',
 DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY)),

('Feature request: dark mode',
 'It would be great to have a dark mode toggle in the settings page for late-night usage.',
 'Amara Okafor', 'amara.okafor@example.com', 'Priya Patel', 'Low', 'Open',
 DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_SUB(NOW(), INTERVAL 4 DAY)),

('Site down for all users',
 'The entire application is returning a 500 error on every page. This is affecting all customers right now.',
 'Carlos Mendes', 'carlos.mendes@example.com', 'Mike Chen', 'High', 'Resolved',
 DATE_SUB(NOW(), INTERVAL 7 DAY), DATE_SUB(NOW(), INTERVAL 6 DAY)),

('Typo on the pricing page',
 'The word "Enterprize" should be spelled "Enterprise" on the pricing comparison table.',
 'Lena Fischer', 'lena.fischer@example.com', 'Priya Patel', 'Low', 'Closed',
 DATE_SUB(NOW(), INTERVAL 10 DAY), DATE_SUB(NOW(), INTERVAL 9 DAY)),

('Export to CSV fails for large datasets',
 'Exporting more than 5,000 rows from the reports page causes the browser tab to crash.',
 'Sarah Johnson', 'sarah.johnson@example.com', 'Unassigned', 'Medium', 'Open',
 DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY));
